/**
 * Display warning notice in the block editor for data catalogue stubs
 */
(function() {
    // Use subscribe instead of domReady to ensure the editor is fully initialized
    const { subscribe, select } = wp.data;
    const unsubscribe = subscribe(() => {
        try {
            const currentPostType = select('core/editor')?.getCurrentPostType();
            if (!currentPostType) {
                return;
            }
            unsubscribe();  // We only need to run this once

            // Check if we're on our custom post type
            if (currentPostType === dataCatalogueSettings.postType) {
                const { createErrorNotice } = wp.data.dispatch('core/notices');                
                // Create a notice that doesn't automatically dismiss
                createErrorNotice(
                    'Do not edit these posts directly. They are externally managed and will be overwritten.', {
                    id: 'data-catalogue-error-notice',
                    isDismissible: false,
                    actions: []
                });
            }
        } catch (error) {
            // If there's any error, unsubscribe to prevent infinite attempts
            unsubscribe();
            console.error('Error displaying data catalogue notice:', error);
        }
    });
})();
