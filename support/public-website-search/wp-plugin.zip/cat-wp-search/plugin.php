<?php
/*
Plugin Name: BAS Data Catalogue Search
Description: Allows items from the BAS Data Catalogue to be searched within WordPress.
Version: 2.0
Author: Felix Fennell
*/

// Register custom post type
add_action('init', function() {
    register_post_type('data_catalogue_stub', [
        'labels' => [
            'name' => 'Data Catalogue Stubs',
            'singular_name' => 'Data Catalogue Stub',
            'add_new' => 'Add New',
            'add_new_item' => 'Add New Data Catalogue Stub',
            'edit_item' => 'Edit Data Catalogue Stub',
            'new_item' => 'New Data Catalogue Stub',
            'view_item' => 'View Data Catalogue Stub',
            'search_items' => 'Search Data Catalogue Stubs',
            'not_found' => 'No Data Catalogue Stubs found',
            'not_found_in_trash' => 'No Data Catalogue Stubs found in Trash',
        ],
        'description' => 'BAS Data Catalogue item stubs for including into website search.',
        'public' => false,
        'exclude_from_search' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'show_in_menu' => 'tools.php',
        'show_in_rest' => true,
        'rest_base' => 'data_catalogue_stub',
        'rest_controller_class' => 'WP_REST_Posts_Controller',
        'supports' => ['title', 'editor', 'thumbnail', 'custom-fields'],
        'has_archive' => false,
        'can_export' => false,
    ]);

        $fields = [
        'file_identifier'   => 'string',
        'file_revision'     => 'string',
        'href'              => 'string',
        'hierarchy_level'   => 'string',
        'publication_date'  => 'string',
        'edition'           => 'string',
        'source'            => 'string',
        'href_thumbnail'    => 'string',
    ];
    
    foreach ($fields as $field => $type) {
        register_meta('post', $field, [
            'object_subtype' => 'data_catalogue_stub',
            'show_in_rest' => true,
            'single' => true,
            'type' => $type,
            'auth_callback' => function() { 
                return current_user_can('edit_posts');
            },
        ]);
    }
});

// Enqueue scripts for the block editor
add_action('enqueue_block_editor_assets', function() {
    $post_type = get_post_type();
    
    // Only load for our custom post type
    if ($post_type === 'data_catalogue_stub') {
        // Register and enqueue the script
        wp_enqueue_script(
            'data-catalogue-editor-notices',
            plugins_url('js/editor-notices.js', __FILE__),
            array('wp-blocks', 'wp-dom-ready', 'wp-edit-post', 'wp-element', 'wp-data'),
            filemtime(plugin_dir_path(__FILE__) . 'js/editor-notices.js'),
            true
        );
        
        // Pass data to the script
        wp_localize_script(
            'data-catalogue-editor-notices',
            'dataCatalogueSettings',
            array(
                'postType' => 'data_catalogue_stub',
                'noticeText' => 'These posts are managed automatically. Manual changes will be overwritten.'
            )
        );
    }
});

// Add meta boxes
add_action('add_meta_boxes', function() {
    add_meta_box(
        'data_catalogue_stub_meta',
        'Data Catalogue Item Details',
        function($post) {
            $file_identifier = get_post_meta($post->ID, 'file_identifier', true);
            $file_revision = get_post_meta($post->ID, 'file_revision', true);
            $href = get_post_meta($post->ID, 'href', true);
            $hierarchy_level = get_post_meta($post->ID, 'hierarchy_level', true);
            $publication_date = get_post_meta($post->ID, 'publication_date', true);
            $edition = get_post_meta($post->ID, 'edition', true);
            $source = get_post_meta($post->ID, 'source', true);
            $href_thumbnail = get_post_meta($post->ID, 'href_thumbnail', true);
            ?>
            <p>
                <label for="file_identifier">File Identifier:</label><br>
                <input type="text" name="file_identifier" id="file_identifier" value="<?php echo esc_attr($file_identifier); ?>" style="width:100%;">
            </p>
            <p>
                <label for="file_revision">File Revision:</label><br>
                <input type="text" name="file_revision" id="file_revision" value="<?php echo esc_attr($file_revision); ?>" style="width:100%;">
            </p>
            <p>
                <label for="href">Href:</label><br>
                <input type="text" name="href" id="href" value="<?php echo esc_attr($href); ?>" style="width:100%;">
            </p>
            <p>
                <label for="hierarchy_level">Hierarchy Level:</label><br>
                <input type="text" name="hierarchy_level" id="hierarchy_level" value="<?php echo esc_attr($hierarchy_level); ?>" style="width:100%;">
            </p>
            <p>
                <label for="publication_date">Publication Date:</label><br>
                <input type="date" name="publication_date" id="publication_date" value="<?php echo esc_attr($publication_date); ?>" style="width:100%;">
            </p>
            <p>
                <label for="edition">Edition:</label><br>
                <input type="text" name="edition" id="edition" value="<?php echo esc_attr($edition); ?>" style="width:100%;">
            </p>
            <p>
                <label for="source">Source:</label><br>
                <input type="text" name="source" id="source" value="<?php echo esc_attr($source); ?>" style="width:100%;">
            </p>
            <p>
                <label for="href_thumbnail">Thumbnail URL:</label><br>
                <input type="text" name="href_thumbnail" id="href_thumbnail" value="<?php echo esc_attr($href_thumbnail); ?>" style="width:100%;">
            </p>
            <?php
        },
        'data_catalogue_stub',
        'normal',
        'default'
    );
});

// Save meta fields
add_action('save_post_data_catalogue_stub', function($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['file_identifier'])) {
        update_post_meta($post_id, 'file_identifier', sanitize_text_field($_POST['file_identifier']));
    }
    if (isset($_POST['file_revision'])) {
        update_post_meta($post_id, 'file_revision', sanitize_text_field($_POST['file_revision']));
    }
    if (isset($_POST['href'])) {
        update_post_meta($post_id, 'href', esc_url_raw($_POST['href']));
    }
    if (isset($_POST['hierarchy_level'])) {
        update_post_meta($post_id, 'hierarchy_level', sanitize_text_field($_POST['hierarchy_level']));
    }
    if (isset($_POST['publication_date'])) {
        update_post_meta($post_id, 'publication_date', sanitize_text_field($_POST['publication_date']));
    }
    if (isset($_POST['edition'])) {
        update_post_meta($post_id, 'edition', sanitize_text_field($_POST['edition']));
    }
    if (isset($_POST['source'])) {
        update_post_meta($post_id, 'source', sanitize_text_field($_POST['source']));
    }
    if (isset($_POST['href_thumbnail'])) {
        update_post_meta($post_id, 'href_thumbnail', esc_url_raw($_POST['href_thumbnail']));
    }
});

// Modify the permalink for data_catalogue_stub post type to use href meta value
add_filter('post_type_link', function($permalink, $post) {
    if ($post->post_type == 'data_catalogue_stub') {
        $href = get_post_meta($post->ID, 'href', true);
        if (!empty($href)) {
            return $href;
        }
    }
    return $permalink;
}, 10, 2);

// Redirect direct access to data_catalogue_stub posts to their href
add_action('template_redirect', function() {
    global $post;
    if (is_singular('data_catalogue_stub')) {
        $href = get_post_meta($post->ID, 'href', true);
        if (!empty($href)) {
            wp_redirect($href, 301);
            exit;
        } else {
            // If no href is set, redirect to home
            wp_redirect(home_url(), 302);
            exit;
        }
    }
});

// Add custom class to search results for this post type to make them visually distinct (optional)
add_filter('post_class', function($classes, $class, $post_id) {
    if (get_post_type($post_id) === 'data_catalogue_stub') {
        $classes[] = 'data-catalogue-search-result';
    }
    return $classes;
}, 10, 3);
