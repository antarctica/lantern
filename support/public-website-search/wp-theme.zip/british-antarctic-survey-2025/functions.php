<?php
// Enqueue parent theme styles
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/style.css');
});

// Require the BAS Data Catalogue Search plugin
add_action('after_setup_theme', function() {
    if (!is_plugin_active('cat-wp-search/plugin.php')) {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error"><p>BAS Data Catalogue Search plugin is required for this theme to function properly.</p></div>';
        });
    }
});

// Helper for is_plugin_active
if (!function_exists('is_plugin_active')) {
    require_once(ABSPATH . 'wp-admin/includes/plugin.php');
}
