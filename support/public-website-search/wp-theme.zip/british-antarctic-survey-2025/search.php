<?php
/**
 * Custom Search Results Template for British Antarctic Survey 2025 Theme
 *
 * This template displays search results, highlighting Data Catalogue Stubs distinctly.
 * All other templates inherit from Twenty Twenty-Five.
 */
// Do NOT call get_header() or get_footer() to hide default WP header/footer for this template only
?><link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
<style>
.work-sans { font-family: 'Work Sans', sans-serif; }
</style>
<body class="bg-white work-sans">
    <nav class="bg-[#013B5C] text-white p-4">
        <div class="container mx-auto flex justify-between items-center">
            <div>
                <img src="https://cdn.web.bas.ac.uk/bas-style-kit/0.7.3/img/logos-symbols/bas-logo-inverse-transparent-64.png" alt="BAS logo" />
            </div>
            <ul class="flex space-x-4">
                <li><a href="/about" class="hover:underline">About</a></li>
                <li><a href="/science" class="hover:underline">Science</a></li>
                <li><a href="/data" class="hover:underline">Data</a></li>
                <li><a href="/polar-operations" class="hover:underline">Polar Operations</a></li>
                <li><a href="/people" class="hover:underline">People</a></li>
                <li><a href="/news" class="hover:underline">News & media</a></li>
                <li><a href="/jobs" class="hover:underline">Jobs</a></li>
                <li><a href="/contact" class="hover:underline">Contact</a></li>
                <li>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z"></path>
                    </svg>
                </li>
            </ul>
        </div>
    </nav>

    <div class="mx-38 mt-2">
        <p class="text-sm text-gray-600">Home / Search results for “<?php echo esc_html(get_search_query()); ?>”</p>
    </div>

    <main class="mx-68 mt-16 space-y-16">
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
                <article class="flex gap-6 items-start">
                    <?php
                    if (get_post_type() === 'data_catalogue_stub') {
                        $href_thumbnail = get_post_meta(get_the_ID(), 'href_thumbnail', true);
                        if (!empty($href_thumbnail)) {
                            // Use the external thumbnail if set
                            ?>
                            <img src="<?php echo esc_url($href_thumbnail); ?>" alt="<?php the_title_attribute(); ?>" class="w-72 h-48 object-contain flex-shrink-0" />
                            <?php
                        } else {
                            // Fallback image
                            ?>
                            <img src="https://cdn-testing.web.bas.ac.uk/scratch/public-website/2025-search/no-image.png" alt="No image" class="w-72 h-48 object-contain flex-shrink-0 bg-gray-100" />
                            <?php
                        }
                    } else if ( has_post_thumbnail() ) {
                        ?>
                        <img src="<?php the_post_thumbnail_url('medium_large'); ?>" alt="<?php the_title_attribute(); ?>" class="w-72 h-48 object-contain flex-shrink-0" />
                        <?php
                    } else {
                        ?>
                        <img src="https://cdn-testing.web.bas.ac.uk/scratch/public-website/2025-search/no-image.png" alt="No image" class="w-72 h-48 object-contain flex-shrink-0 bg-gray-100" />
                        <?php
                    }
                    ?>
                    <div class="flex flex-col space-y-4">
                        <small class="uppercase">
                            <?php
                                if (get_post_type() === 'data_catalogue_stub') {
                                    echo 'Data Catalogue Item';
                                } else {
                                    echo esc_html(get_post_type_object(get_post_type())->labels->singular_name);
                                }
                            ?>
                        </small>
                        <h1 class="text-2xl font-semibold"><a class="text-[#013B5C]" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
                        <div class="text-gray-700"><?php the_excerpt(); ?></div>
                    </div>
                </article>
                <hr class="border-gray-300" />
            <?php endwhile; ?>
            <div class="mt-8"><?php the_posts_navigation(); ?></div>
        <?php else : ?>
            <p class="text-gray-600">No results found.</p>
        <?php endif; ?>
    </main>
</body>
